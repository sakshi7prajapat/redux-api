import logo from './logo.svg';
import './App.css';
import User from './component/user';
import Cards from './component/Card';


function App() {
  return (
    <div className="App">
    <Cards/>
    </div>
  );
}

export default App;
