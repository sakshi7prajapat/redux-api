
import React, { useState, useEffect } from 'react';
const User = () =>{

    return (<>
    hello
    </>);
}

export default User;