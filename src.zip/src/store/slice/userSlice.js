import { createSlice , createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchData = createAsyncThunk ( 'fetchApi', async()=>{
    try {
        const response = 
            await axios.get(' https://jsonplaceholder.typicode.com/posts');
            console.log(response.data)
        return response.data;
    } catch (error) {
        throw error;
    }
}

);

const CardSlice = createSlice({
    name:"posts",
    initialState : {
        data:[],
        loading: false,
        error: null,
    },
    reducers:{
      removeCard : (state,action) =>{
            
      },
     extraReducer : (builder) =>{
        builder.addCase(fetchData.fulfilled,(state,action)=>{
            state.loading = false;
            state.data = action.payload;
        }).addCase(fetchData.pending, (state) => {
            state.loading = true;
            state.error = null;
          }).addCase(fetchData.rejected, (state) => {
            state.loading = true;
            state.error = null;
          });

       }

    }
});

export const  {removeCard} = CardSlice.actions;
export default CardSlice.reducer;